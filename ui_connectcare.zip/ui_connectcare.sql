-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 10, 2025 at 01:31 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.1.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ui_connectcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `college_info`
--

CREATE TABLE `college_info` (
  `college_id` int(11) NOT NULL,
  `college_name` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `establishment_year` int(11) DEFAULT NULL,
  `college_type` varchar(50) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(15) DEFAULT NULL,
  `website_url` varchar(255) DEFAULT NULL,
  `num_students` int(11) DEFAULT NULL,
  `accreditation` varchar(255) DEFAULT NULL,
  `courses_offered` text DEFAULT NULL,
  `facilities` text DEFAULT NULL,
  `avg_tuition_fee` decimal(10,2) DEFAULT NULL,
  `ranking` int(11) DEFAULT NULL,
  `hostel_available` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` varchar(30) NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `college_info`
--

INSERT INTO `college_info` (`college_id`, `college_name`, `location`, `latitude`, `longitude`, `establishment_year`, `college_type`, `contact_email`, `contact_phone`, `website_url`, `num_students`, `accreditation`, `courses_offered`, `facilities`, `avg_tuition_fee`, `ranking`, `hostel_available`, `created_at`, `updated_at`, `status`) VALUES
(1, 'Green Valley University', 'Green Valley, CA', 36.77830000, -119.41790000, 1995, 'Public', 'info@gvu.edu', '9800980098', 'https://gvu.edu', 5000, 'Accredited by NAAC', 'B.Sc, M.Sc, PhD', 'Library, Sports, Cafeteria', 12000.50, 45, 'Yes', '2025-01-10 05:05:27', '2025-01-29 05:02:10', ''),
(2, 'RMDIOT College', 'Chinchwad', 12.23322300, 23.13234300, 2000, 'Private', 'rmdiot@college.com', '8900890089', 'https://www.rmdiot.in/', 3000, 'NAAC NBA', 'MBA Engineering BCOM BA', 'Library, Sports, Cafeteria', 12000.00, 32, 'Yes', '2025-01-29 05:01:54', '2025-01-29 05:01:54', ''),
(3, 'VB Kolte', 'Malkapur', 12.23322300, 23.13234300, 2010, 'Private', 'vbk@gmail.com', '8900890078', 'https://www.vbk.in/', 2000, 'NAAC NBA', 'MBA BBM BE BCA ME', 'Sport Special program NCC NSS', 31995.00, 102, 'No', '2025-02-10 16:31:28', '2025-02-10 16:31:28', ''),
(4, 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', 'Muktainagar Rode Malkapur, buldhana', 20.89967923, 76.20080198, 2010, 'Private', 'coemalkapur@rediffmail.com', '7267295037', 'https://coemalkapur.ac.in/engg/', 30000, 'A+', 'Courses	Seats\r\nB.E. in Civil Engineering	60\r\nB.E. in Computer Science and Engineering	60\r\nB.E. in Electrical Engineering	60\r\nB.E. in Mechanical Engineering	60', 'labs, classrooms, a library, sports grounds, and a canteen.', 35000.00, 3, 'Yes', '2025-02-15 06:54:20', '2025-02-15 06:54:20', ''),
(5, 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', 'at post asalgaon tq jalgaon jamod dist buldhana', 19.87575400, 75.48107860, 2010, 'Private', 'coemalkapur@rediffmail.com', '7517744852', 'https://coemalkapur.ac.in/engg/', 15000, 'A+', 'cse', 'air', 28000.00, 2, 'Yes', '2025-03-19 19:07:13', '2025-03-19 19:07:13', ''),
(6, 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', 'at post asalgaon tq jalgaon jamod dist buldhana', 19.87575400, 75.48107860, 2010, 'Private', 'coemalkapur@rediffmail.com', '7517744852', 'https://coemalkapur.ac.in/engg/', 20015, 'A+', 'cse', 'g', 2800.00, 2, 'Yes', '2025-03-19 19:20:27', '2025-03-19 19:20:27', ''),
(7, 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', 'at post asalgaon tq jalgaon jamod dist buldhana', 19.87575400, 75.48107860, 2015, 'Private', 'coemalkapur@rediffmail.com', '7517744852', 'https://coemalkapur.ac.in/engg/', 2500, 'A+', 'cse', 'ssc', 2800.00, 1, 'Yes', '2025-03-19 19:33:03', '2025-05-01 11:55:30', 'NotAvailable'),
(8, 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', 'at post asalgaon tq jalgaon jamod dist buldhana', 19.87575400, 75.48107860, 2010, 'Government', 'coemalkapur@rediffmail.com', '7517744852', 'https://coemalkapur.ac.in/engg/', 2000, 'A+', 'cse', 'scs', 2800.00, 1, 'Yes', '2025-03-19 19:39:12', '2025-05-01 11:55:24', 'NotAvailable'),
(9, 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', 'at post asalgaon tq jalgaon jamod dist buldhana', 19.87575400, 75.48107860, 2015, 'Government', 'coemalkapur@rediffmail.com', '7517744852', 'https://coemalkapur.ac.in/engg/', 200, 'A+', 'sce', 'sd', 2800.00, 1, 'Yes', '2025-03-19 19:40:00', '2025-03-19 19:40:44', 'NotAvailable'),
(10, 'Shri Sant Gajanan Maharaj College Of Engineering', ' Khamgaon Road, SHEGAON  444203, Dist. Buldhana', 20.79271300, 76.69432800, 1983, 'Private', 'registrar@ssgmce.ac.in', '8669638081', 'http://ssgmce.ac.in', 1600, 'A+', 'B.E./B.Tech, M.E./M.Tech, and MBA/PGDM programs\r\n', 'hostels, sports complex, modern laboratories, central library\r\n', 265000.00, 92, 'Yes', '2025-05-01 10:26:24', '2025-05-01 10:26:24', 'Available'),
(11, 'G S College khamgaon', 'Vitthal Nagar, Khamgaon, Maharashtra 444303', 20.69995000, 76.62760000, 1947, 'Private', 'gskhamgaonprincipal@gmail.com', '07263255200', 'https://gsck.ac.in/#:~:text=With%20Tamso%20Maa%20Jyotirgamaya%20as,%2C%20courage%2C%20patriotism%2C%20discipline%2C', 5000, 'A+', 'B.Sc.\r\nB.C.A.\r\nM.Sc. (Botany / Chemistry / Zoology)\r\nM.Sc. (Physics / Mathematics)\r\nM.Sc. (Computer Science)', 'a library with over 70,000 books, a botanical garden, a swimming pool, an indoor stadium, and multiple sports grounds.', 17264.00, 4, 'Yes', '2025-05-01 10:30:51', '2025-05-01 10:30:51', 'Available'),
(12, 'Vivekanand Agriculture College, Hiwara Ashram', '6FPR+7C8, Ashram, Hiwrashram, Hiwara Bk., Maharashtra 444301', 21.49104900, 80.16007200, 2003, 'Government', 'vachiwara@gmail.com', '09767897910', 'https://admissionagricultureveterinary.info/college/vivekanand-agriculture-college', 506, 'A+', 'Bachelor of Science (B.Sc.) degree in Agriculture and a Bachelor of Science (B.Sc.) degree in Horticulture', 'sport, library, computer labs', 2600000.00, 4, 'Yes', '2025-05-01 10:36:25', '2025-05-01 10:36:25', 'Available'),
(13, 'Rajashri Shahu College Of Pharmacy buldhana', 'Rajarshi Shahu College of Pharmacy, At & Post  Malvihir, Buldana', 20.51486800, 76.20644800, 2012, 'Private', 'info@rscp.ac.in', '9552291159', 'https://rscp.ac.in/contact/', 900, '', 'B Pharma', 'Decent R.C.C. building with ultra-modern facility for laboratories, Classrooms, Tutorial rooms, Library', 315000.00, 4, 'Yes', '2025-05-01 10:40:34', '2025-05-01 10:40:34', 'Available'),
(14, 'Rajendra gode pharmacy college of malkapur', 'R6X2+VWQ, MH SH 176, near Nimbari, Phata, Buldana, Wakodi, Maharashtra 443101', 19.87575400, 75.33931950, 2005, 'Private', 'drgcopmalkapur@gmail.com', '07267227337', 'https://drgcop.co.in/', 225, 'b+', 'B pharma \r\nM pharma', 'sport , libraries', 95000.00, 4, 'No', '2025-05-01 10:46:56', '2025-05-01 10:46:56', 'Available'),
(15, 'Siddhivinayak Technical Campus (STC), khamgaon', 'Shegaon Rd, Jaipur Londe, Maharashtra 444203', 20.71162200, 76.56613200, 2011, 'Private', 'stc.shegaon@stc.org.in', '09623464411', 'https://stc.org.in/', 495, 'approved by the All India Council for Technical Education (AICTE) and affiliated with Sant Gadge Baba Amravati University (SGBAU)', 'Bachelor of Engineering (B.E.) and Diploma programs. They specialize in Civil Engineering, Computer Science Engineering, Electrical Engineering, Electronics Engineering, and Mechanical Engineering', 'sport, NSS, Library , computer labs , wifi facilities', 115000.00, 3, 'No', '2025-05-01 10:53:20', '2025-05-01 10:53:20', 'Available'),
(16, 'Pankaj Laddhad Institute of Technology and Management Studies (PLITMS) buldhana', 'F6H5+GXV, Chikhali Rd, Yelgaon, Maharashtra 443001', 76.21000000, 20.47880000, 2009, 'Private', 'plitprincipal@gmail.com', '8080237640', 'https://plit.ac.in/', 325, 'AICTE, NAAC', 'B.E./B.Tech, M.E./M.Tech, and MBA/PGDM courses', 'sport, Library , computer labs , wifi facilities', 501441.00, 3, 'Yes', '2025-05-01 10:59:21', '2025-05-01 10:59:21', 'Available'),
(17, 'Anuradha Engineering College (AEC) chikhli', '964F+PFP, Sakegaon Road,Chikhli, CHIKHLI,Dist Buldana Maharashtra, Maharashtra 443201', 20.35681280, 76.14130080, 1993, 'Private', 'principal@aecc.ac.in', '07264242063', 'https://aecc.ac.in/', 731, 'AICTE NBA', 'B.Tech in Computer Science and Engineering, Information Technology, Electronics and Telecommunication Engineering, Mechanical Engineering, and Chemical Engineering', 'well-equipped laboratories, a library with extensive resources, an IT infrastructure with high-speed internet, and sports facilities like an indoor stadium and gymnasium', 71930.00, 3, 'Yes', '2025-05-01 11:08:23', '2025-05-01 11:08:23', 'Available'),
(18, 'Shri Shivaji Science and Arts College, Chikhli', '9727+7V7, MH SH 176, Gandhi Nagar, Chikhli, Maharashtra 443201', 20.35064740, 76.22347290, 1967, 'Private', 'shivajichk@rediff.com', '07264242088', 'https://shivajichk.ac.in/', 1043, 'B+', 'Art Science ', 'sport, library', 65000.00, 4, 'Yes', '2025-05-01 11:12:23', '2025-05-01 11:12:23', 'Available'),
(19, 'Shri Sant Gajanan Maharaj College of Pharmacy buldhana', 'Shahu Nagar, near Palghar, Sagwan, Maharashtra', 20.51665730, 76.13363390, 2019, 'Private', 'principalcopbuldana@gmail.com', '7498032048', 'https://www.ssgmcop.ac.in/', 295, 'AICTE', 'B. Pharma (Bachelor of Pharmacy), M. Pharma (Master of Pharmacy), and D. Pharma (Diploma in Pharmacy', 'central library, digital library, internet facility', 72000.00, 4, 'Yes', '2025-05-01 11:16:05', '2025-05-01 11:16:05', 'Available'),
(20, 'Mauli Group of Institutions, College of Engineering and Technology, Shegaon', 'QM62+R3M, Khamgaon Rd, Shegaon, Sawarna, Maharashtra 444203', 20.77753420, 76.65000470, 2015, 'Government', 'xyz@gmail.com', '07265254462', 'https://www.shiksha.com/college/college-of-engineering-and-technology-shegaon-mauli-s-group-of-institutions-maharashtra-other-61933', 2500, 'AICTE ', '(B.E./B.Tech) and postgraduate (M.E./M.Tech) programs in various engineering disciplines', 'transportation, library, internet facility, canteen, computer labs', 67094.00, 4, 'Yes', '2025-05-01 11:21:23', '2025-05-01 11:21:23', 'Available'),
(21, 'Rajarshi Shahu College of Engineering (RSCE), Buldhana', 'G59F+HH4, Near Palna Ghar, Sagwan Road, Buldhana, Maharashtra 443001', 20.51887110, 76.13276420, 2008, 'Private', 'rscoe363@sgbau.ac.in', '07262287167', 'https://rsce.ac.in/', 134, 'AICTE, NAAC', 'B.E. / B.Tech and M.E./M.Tech programs', 'sport, NSS, canteen , Computer labs,', 27000.00, 3, 'No', '2025-05-01 11:24:01', '2025-05-01 11:24:01', 'Available'),
(22, 'Anuradha Engineering, College road, Chikhli, Dolkheda, Maharashtra 443201', 'Anuradha Engineering, College road, Chikhli, Dolkheda, Maharashtra 443201', 20.72092500, 78.60386900, 1995, 'Private', 'principal.acpchikhli@gmail.com', '07264243285', 'https://anuradhapharmacydegree.co.in/', 265, 'SGBAU , MSBTE', 'B.Tech degrees in Computer Science, Information Technology, Electronics and Telecommunication Engineering, Chemical Engineering, and Mechanical Engineering, as well as M.E./M.Tech programs in Computer Science, Chemical Engineering, and Mechanical CAD/CAM. They also offer PhD programs in Mechanical Engineering, Chemical Engineering, Computer Science & Engineering, and Chemistry', 'library, modern labs, sport, canteen , gym , stadium etec', 258992.00, 3, 'Yes', '2025-05-01 11:27:42', '2025-05-01 11:27:42', 'Available'),
(23, 'Government B.Ed. College, Buldhana', 'G5GP+4WG, Chaitanyawadi, Buldhana, Maharashtra 443001', 20.52960000, 76.17910000, 1968, 'Government', 'pradeepkauthalkar@gmail.com', '7517744852', 'https://www.shiksha.com/college/government-b-ed-college-buldana-119129', 150, 'A', '.Ed and M.Ed programs, primarily in Teaching & Education', 'library, reading room, seminar hall, and language lab.  a cafeteria, gym, and sports complex,', 27800.00, 4, 'Yes', '2025-05-01 11:31:10', '2025-05-01 11:31:10', 'Available'),
(24, 'Jijamata Mahavidyalaya, Buldhana', 'G5GM+JVP, Chikhali Rd, Ashtavinayak Nagar, Buldhana, Maharashtra 443001', 20.52960000, 76.17910000, 1956, 'Government', 'jijamatabld@gmail.com', '09420147249', 'https://jmvbuldhana.ac.in/', 1055, 'A+', 'B.A., B.Com., B.Sc., M.A., M.Com., and M.Sc. in various subjects like Economics, English, Marathi, Music, Chemistry, History, and more. They also offer Ph.D.', 'Departmental Library, Books Theses Journals ,Internet facilities , Computers with internet', 35000.00, 4, 'Yes', '2025-05-01 11:35:56', '2025-05-01 11:35:56', 'Available'),
(25, 'GOVERNMENT POLYTECHNIC, KHAMGAON', 'Government Polytechnic, Khamgaon Jalamb Road, In Front of ITI , Khamgaon - 444303, Maharashtra, India.', 20.72695360, 76.52547370, 1961, 'Private', 'gpkhamgaon@dtemaharashtra.gov.in', '07263295011', 'http://www.gpk.edu.in/', 5000, 'AICTE, NAAC', 'Diploma in Civil Engineering:\r\nDiploma in Computer Engineering:\r\nDiploma in Electronics & Communication Engineering:\r\nDiploma in Mechanical Engineering:\r\nDiploma in Electrical Engineering:', 'well-equipped library, separate boys\' and girls\' hostels, a sports complex, and various student support services.', 7750.00, 4, 'Yes', '2025-05-01 11:38:25', '2025-05-01 11:38:25', 'Available'),
(26, 'Government College of Engineering, Jalgaon', 'Opp. Government ITI, NH 6, National Highway 6, Ramanand Nagar, Jalgaon, Maharashtra 425001', 21.00230000, 75.56130000, 1996, 'Government', 'principal@gcoej.ac.in', '02572281522', 'https://www.gcoej.ac.in/', 988, 'AICTE, NAAC', 'B.E. / B.Tech in Civil, Electrical, Electronics and Telecommunication, and Mechanical Engineering, as well as M.E. / M.Tech programs in Electrical Instrumentation and Control, Electronics and Telecommunication, and Heat Power Engineering', 'hostel accommodation, library access, labs, a cafeteria, gym, medical facilities, and sports facilities', 15000.00, 3, 'Yes', '2025-05-01 11:42:16', '2025-05-01 11:42:16', 'Available'),
(27, 'Government Medical College, Jalgaon', '2H59+G2F, CIVIL HOSPITAL CAMPUS, Jilha Peth, Old B J Market, Jaikisan Wadi, Jalgaon, Maharashtra 425001', 20.93081800, 75.61136700, 2018, 'Government', 'deangmcjalgaon@gmail.com', '02572222917', 'https://gmcjalgaon.org/', 209, 'A+', 'MBBS, MD, and MS course', 'hostels, a hospital, library, sports facilities, and cafeteria, sport, ATM,', 108400.00, 4, 'Yes', '2025-05-01 11:46:03', '2025-05-01 11:46:03', 'Available'),
(28, 'Shramsadhana Bombay Trust, College of Engineering & Technology, Jalgaon', 'Bambhori Pr. Chandsar, Jalgaon, Maharashtra 425001', 20.93081800, 75.61136700, 1983, 'Private', 'sscoetjal@gmail.com', '0252258393', 'https://www.sscoetjalgaon.ac.in/', 2474, 'A+', '(B.E.) / Bachelor of Technology (B.Tech) programs include Biotechnology, Civil, Chemical, Computer, Electronics and Telecommunication, Electrical, Mechanical, and Information Technology. Additionally, they offer Master of Engineering (M.E.) / Master of Technology (M.Tech), MBA/PGDM, and MCA courses', '24x7 Wifi Facility,  Facilities, Hostel Facility, Best Teachers , Medical Facility, Green Lush Campus, sport,, Canteen', 75000.00, 4, 'Yes', '2025-05-01 11:49:54', '2025-05-01 11:49:54', 'Available'),
(29, 'P. R. Pote Patil College of Engineering and Management', 'Pote Estate, Kathora Rd, Amravati, Maharashtra 444602', 20.59160000, 77.45260000, 2008, 'Private', 'principal@prpotepatilengg.ac.in', '7517744852', 'https://prpotepatilengg.ac.in/contact-us', 329, 'A++, NAAC', 'Computer Science and Engineering (CSE)\r\nArtificial Intelligence & Data Science\r\nElectronics & Telecommunication Engineering\r\nElectrical Engineering\r\nMechanical Engineering\r\nCivil Engineering\r\nComputer Science & Engineering (AIML) \r\nPostgraduate (PG) Programs:\r\nMBA\r\nMCA\r\nM.Tech: in various engineering disciplines like Computer Science, Electrical Engineering, and more', 'well-equipped laboratories, a modern library with digital media, multimedia classrooms, and a large auditorium, sport', 77410.00, 4, 'Yes', '2025-05-01 11:54:34', '2025-05-01 11:54:34', 'Available'),
(30, 'College of engineering pune', 'Wellesley Rd, Shivajinagar, Pune, Maharashtra 411005', 18.53039350, 73.85381190, 1854, 'Private', 'dean.engineering@coeptech.ac.in', '02025507000', 'https://www.coeptech.ac.in/', 3668, 'NBA NAAC', 'hostels (separate for boys and girls), sports facilities (including a stadium and other grounds), a library, auditoriums, and Wi-Fi', 'B.Tech degrees in various engineering specializations and B.Plan', 163240.00, 4, 'Yes', '2025-05-01 13:08:33', '2025-05-01 13:08:33', 'Available'),
(31, 'Government College of Engineering, Aurangabad (GECA)', 'Bhanudas Sabhahgrah Railway Station Rd, Rachanakar Colony, New Usmanpura, Chhatrapati Sambhaji Nagar, Maharashtra 431005', 19.87640000, 75.34320000, 1960, 'Government', 'dean-academics@geca.ac.in', '02402366101', 'https://geca.ac.in/', 600, 'AICTE', 'Engineering in Civil \r\nEngineering in Computer \r\nEngineering in Electronics & Communication\r\nEngineering in Mechanical \r\nEngineering in Electrical', 'hostels, a hospital, library, sports facilities, and cafeteria, sport, ATM,', 71801.00, 4, 'Yes', '2025-05-01 13:13:39', '2025-05-01 13:13:39', 'Available'),
(32, 'Government Medical College, Aurangabad', 'University Rd, Jubilee Park, Chhatrapati Sambhaji Nagar, Maharashtra 431004', 19.97065000, 75.38230000, 1956, 'Government', 'deangmca@gmail.com', '02402402412', 'http://www.gmcaurangabad.com/', 200, 'NMC, MCI', 'MBBS, MD, MS, DM, MCh, and PG Diploma programs', 'academic infrastructure like classrooms and labs, hostel accommodation, and a well-equipped library with Wi-Fi and reading materials', 103900.00, 4, 'Yes', '2025-05-01 13:17:05', '2025-05-01 13:17:05', 'Available'),
(33, 'Government Medical College, Nagpur', '43GW+CR2, Hanuman Nagar, Ajni Rd, Medical Chowk, Ajni, Nagpur, Maharashtra 440003', 21.15494100, 79.09345400, 1947, 'Government', 'deangmc2@gmail.com', '07122743588', 'https://gmcnagpur.org/contacts', 200, 'NMC, MUHS', 'MBBS, MD, MS, DM, M.Ch., and various postgraduate diploma programs', 'a library, hostels, mess, labs, and sports facilities', 118300.00, 4, 'Yes', '2025-05-01 13:21:52', '2025-05-01 13:21:52', 'Available'),
(34, 'Dr. Panjabrao Deshmukh Krishi Vidyapeeth, Akola', 'P22P+3JW, P.O. Krishi Nagar, Maharashtra 444104', 20.73200000, 77.02321000, 1969, 'Government', 'info@pdkvu.in', '7588763787', 'https://www.pdkv.ac.in/?s', 150, 'NAEAB, ICAR', 'B.Sc. in Agriculture, Horticulture, Forestry, B.Tech in Agricultural Engineering, M.Sc. in various agricultural sciences, and MBA/PGDM in Agribusiness', 'Gym , labs , sports, library , cafeteria, auditorium', 100480.00, 3, 'Yes', '2025-05-01 13:32:58', '2025-05-01 13:32:58', 'Available'),
(35, 'Vasantrao Naik Marathwada Krishi Vidyapeeth, Parbhani', '7Q2W+83F, Basmat Road, Krishinagar, Parbhani, Maharashtra 431402', 19.25779000, 76.77374300, 1972, 'Government', 'reg_mau@rediffmail.com', '02452223801', 'https://www.vnmkv.ac.in/', 200, 'A+', 'undergraduate (UG), postgraduate (PG), and doctoral programs in various agricultural fields. The university offers B.Sc. (Hons.) in Agriculture, B.Tech (Food Science), M.Sc. in various agricultural disciplines, and M.Tech (Agricultural Engineering), among others. They also offer Ph.D. programs.', 'accommodation, a library with modern amenities, sports facilities, a canteen, and health services.', 100000.00, 4, 'Yes', '2025-05-01 13:38:37', '2025-05-01 13:38:37', 'Available'),
(36, 'Padmashri Dr. V.B. Kolte College of Engineering', 'V6X2+2JW, Muktainagar Road, Buldana, Malkapur, Maharashtra 443101', 20.52280000, 76.20450000, 2010, 'Government', 'coemalkapur@rediffmail.com', '07267226700', 'https://coemalkapur.ac.in/engg/index.php/contact-us/', 1061, 'NAAC, AICTE Affiliated by SGBAU Approved by DTE MSBTE, Mumbai', 'B.E. / B.Tech in Computer Science and Engineering\r\nB.E. / B.Tech in Electrical Engineering\r\nB.E. / B.Tech in Mechanical Engineering\r\nB.E. / B.Tech in Civil Engineering\r\nM.E. CAD/CAM\r\nM.E. Computer Engineering\r\nM.E. Electrical Engineering', 'NCC, NSS, Library, computer labs , wifi , canteen , sport', 60000.00, 4, 'Yes', '2025-05-01 13:44:25', '2025-05-01 13:44:25', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `diseases_medicine`
--

CREATE TABLE `diseases_medicine` (
  `id` int(11) NOT NULL,
  `symptons` text DEFAULT NULL,
  `diseases` varchar(300) DEFAULT NULL,
  `medicine` text DEFAULT NULL,
  `hospital_id` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diseases_medicine`
--

INSERT INTO `diseases_medicine` (`id`, `symptons`, `diseases`, `medicine`, `hospital_id`) VALUES
(1, 'Watery diarrhea.\nRice-water stools.\nFishy odor to stools.\nVomiting.\nRapid heart rate.\nLoss of skin elasticity. \nDry mucous membranes dry mouth.\nLow blood pressure.\nThirst.\nMuscle cramps (leg cramps, for example).\nRestlessness or irritability (especially in children).\nUnusual sleepiness or tiredness.\nRectal pain.\neye Pain.\nFever.\nSevere vomiting.\nDehydration.\nLow or no urine output.\nWeight loss.\nSeizures.\nShock.', 'Cholera', 'Antacids\r\nBismuth Subsalicylate\r\nHistamine H2 Receptor Antagonists\r\nHyoscyamine\r\nProton Pump Inhibitors\r\nSimethicone\r\nSodium Bicarbonate', '1,2,4,3,5'),
(2, 'Increased thirst.\nFrequent urination.\nExtreme hunger.\nUnexplained weight loss.\nFatigue.\nIrritability.\nBlurred vision.\nSlow-healing sores.\nFrequent infections, such as gums or skin infections and vaginal infections.', 'Diabetes', 'Anti-acne Cleansing (Topical)\r\nTopical Antibiotics (Clindamycin, Erythromycin)\r\nOral Antibiotics(Tetracyclines, Metronidazole)\r\nAzelaic Acid\r\nBenzoyl Peroxide\r\nIsotretinoin\r\nKeratolytics\r\nRetinoids (Topical)\r\n', '2,4,6,7'),
(3, 'poor appetite.\r\nheadaches.\r\ndiarrhea.\r\ngeneralized aches and pains.\r\nfever.\r\nlethargy.', 'Typhoid', 'Fluorouracil\r\nMasoprocol\r\n', '1,3,4'),
(4, 'Memory loss that disrupts daily life.\nChallenges in planning or solving problems.\nDifficulty completing familiar tasks.\nConfusion with time or place.\nTrouble understanding visual images and spatial relationships.\nNew problems with words in speaking or writing.\nMisplacing things and losing the ability to retrace steps.', 'Alzheimer\'s disease', 'Antithrombotic Agents\r\nNitroglycerin\r\nAngiotensin Converting Enzyme (ACE) Inhibitors\r\nBeta-Adrenergic Blockers\r\nAngiotensin-Receptor Blockers\r\nThrombolytics', '1,5,7'),
(5, 'Shortness of breath.\r\nChest tightness or pain.\r\nTrouble sleeping caused by shortness of breath, coughing or wheezing.\r\nA whistling or wheezing sound when exhaling (wheezing is a common sign of asthma in children).', 'Asthama', 'Adrenocorticoids (Systemic)\r\n', '2,5,7'),
(6, 'itching, stinging, and burning between your toes or on soles of your feet.\r\nblisters on your feet that itch.\r\ncracking and peeling skin on your feet, most commonly between your toes and on your soles.\r\ndry skin on your soles or sides of your feet.\r\nraw skin on your feet.', 'Athlete\'s foot', 'Dehydroepiandrosterone (DHEA)\r\n', '3,4,6'),
(8, 'A large brownish spot with darker speckles.\r\nA mole that changes in color, size or feel or that bleeds.\r\nA small lesion with an irregular border and portions that appear red, pink, white, blue or blue-black.\r\nA painful lesion that itches or burns.', 'Cancer Of The Skin', '	Benzodiazepines\r\n	Beta Adrenergic Blocking Agents\r\n	Carbamazepine\r\n	Disulfiram\r\n	Hydroxyzine\r\n	Lithium\r\n	Naltrexone\r\n	Thiamine\r\n	Phenobarbital\r\n', '5,7'),
(9, 'Severe headache.\r\nFatigue or confusion.\r\nVision problems.\r\nChest pain.\r\nDifficulty breathing.\r\nIrregular heartbeat.\r\nBlood in the urine.\r\nPounding in your chest, neck, or ears.', 'Hypertension', '	Adrenocorticoids (Nasal Inhalation, Oral Inhalation, Systemic)\r\n	Antihistamines\r\n	Antihistamines, Non-sedating\r\n	Antihistamines, Phenothiazine-Derivative\r\n	Azelastine\r\n	Cromolyn\r\n	Decongestants (Ophthalmic)\r\n	Ephedrine\r\n	Hydroxyzine\r\n', '1,7'),
(10, 'Difficulty falling asleep at night.\r\nWaking up during the night.\r\nWaking up too early.\r\nNot feeling well-rested after a night\'s sleep.\r\nDaytime tiredness or sleepiness.\r\nIrritability, depression or anxiety.\r\nDifficulty paying attention, focusing on tasks or remembering.\r\nIncreased errors or accidents.', 'Insomnia', '	Dutasteride\r\n	Finasteride\r\n	Minoxidil\r\n', '1,5'),
(11, 'Feeling nauseated.\r\nVomiting.\r\nAbnormal or jerking eye movements (nystagmus)\r\nHeadache.\r\nSweating.\r\nRinging in the ears or hearing loss.', 'Vertigo', '	Carbonic Anhydrase Inhibitors\r\n', '3,7'),
(12, 'Red, swollen tonsils.\r\nWhite or yellow coating or patches on the tonsils.\r\nSore throat.\r\nDifficult or painful swallowing.\r\nFever.\r\nEnlarged, tender glands (lymph nodes) in the neck.\r\nA scratchy, muffled or throaty voice.\r\nBad breath.', 'Tonsillitis', '	Cholinesterase Inhibitors\r\n	Memantine\r\n', '3,5,7'),
(13, 'Pinkness or redness.\r\nSkin that feels warm or hot to the touch.\r\nPain, tenderness and itching.\r\nSwelling.\r\nSmall fluid-filled blisters, which may break.\r\nHeadache, fever, nausea and fatigue if the sunburn is severe', 'Sunburn', '	Chloroquine\r\n	Iodoquinol\r\n	Metronidazole\r\n', '2,4,6,7'),
(14, 'Delusions.\r\nHallucinations.\r\nDisorganized speech (e.g., frequent derailment or incoherence)\r\nGrossly disorganized or catatonic behavior.\r\nA set of three negative symptoms (a “flattening” of one\'s emotions, alogia, avolition)', 'Schizophrenia', '	Bromocriptine\r\n	Progestins\r\n', '1,3,4,6'),
(15, 'Itching\r\nRash\r\nSores\r\nThick crusts', 'Scabies', ' Lateral Sclerosis (ALS)	Riluzole\r\n', '2,4,5'),
(16, 'pain or tenderness in the bones of the arms, legs, pelvis, or spine.\r\nstunted growth and short stature.\r\nbone fractures.\r\nmuscle cramps.\r\nteeth deformities, such as: delayed tooth formation. holes in the enamel. ...\r\nskeletal deformities, including: an oddly shaped skull. bowlegs, or legs that bow', 'Rickets', '	Adrenocorticoids (Systemic)\r\n	Androgens\r\n	Cyclosporine\r\n	Folic Acid\r\n	Iron Supplements\r\n	Leucovorin\r\n	Vitamin B-12\r\n', '2,5,7,6'),
(17, 'Tremor. A tremor, or shaking, usually begins in a limb, often your hand or fingers. \r\nSlowed movement (bradykinesia)\r\nRigid muscles\r\nImpaired posture and balance\r\nLoss of automatic movements\r\nSpeech changes\r\nWriting changes', 'Parkinson\'s disease', '	Antiplatelet Agents\r\n	Beta Adrenergic Blocking Agents\r\n	Calcium Channel Blockers\r\n	Ranolazine\r\n	Nitrates\r\n', '1,2,3,6'),
(18, 'Fear of being contaminated by germs or dirt or contaminating others.\r\nFear of losing control and harming yourself or others.\r\nExcessive focus on religious or moral ideas.\r\nFear of losing or not having things you might need.', 'Obsessive compulsive disorder', '	Calcium Carbonate\r\n	Calcium Gluconate\r\n	Potassium Chloride\r\n	Antidepressants, Tricyclic\r\n	Progestins\r\n	Fluoxetine\r\n', '2,3,4,7'),
(19, 'headaches.\r\neye pain.\r\nnausea.\r\nvomiting.\r\nblurry, or cloudy vision.\r\nsensitivity to light.\r\ndifficulty seeing into the distance.', 'Obsessive compulsive disorder', '	Antidepressants (Tricyclic, SSRIs, SNRIs)\r\n	Barbiturates\r\n	Benzodiazepines\r\n	Beta Adrenergic Blocking Agents\r\n	Buspirone\r\n	Ergotamine, Beladonna and Phenobarbital\r\n	Haloperidol\r\n	Hydroxyzine\r\n	Loxapine\r\n	Meprobamate\r\n	Phenothiazines\r\n	Thiothixene\r\n', '3.5,7'),
(20, 'Night Blindness', 'Night Blindness', '	Antihistamines\r\n	Dronabinol\r\n	Megestrol\r\n', '2,4,5,7');

-- --------------------------------------------------------

--
-- Table structure for table `favorite_places`
--

CREATE TABLE `favorite_places` (
  `id` int(11) NOT NULL,
  `place_id` varchar(30) DEFAULT NULL,
  `user_id` varchar(30) DEFAULT NULL,
  `mark_datetime` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorite_places`
--

INSERT INTO `favorite_places` (`id`, `place_id`, `user_id`, `mark_datetime`) VALUES
(3, '1', '5', '2025-02-01 13:28:51'),
(4, '2', '9', '2025-02-14 18:22:18'),
(5, '10', '11', '2025-02-15 12:46:03');

-- --------------------------------------------------------

--
-- Table structure for table `historical_places_details`
--

CREATE TABLE `historical_places_details` (
  `place_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `about_place` text NOT NULL,
  `filename` varchar(100) DEFAULT NULL,
  `established_year` varchar(10) DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `latitude` varchar(30) DEFAULT NULL,
  `longitude` varchar(30) DEFAULT NULL,
  `entry_fee` varchar(30) DEFAULT NULL,
  `opening_hours` varchar(100) DEFAULT NULL,
  `contact_info` varchar(255) DEFAULT NULL,
  `website_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `offline_map` varchar(100) NOT NULL DEFAULT 'None',
  `status` varchar(30) NOT NULL DEFAULT 'Available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `historical_places_details`
--

INSERT INTO `historical_places_details` (`place_id`, `name`, `city`, `about_place`, `filename`, `established_year`, `category`, `latitude`, `longitude`, `entry_fee`, `opening_hours`, `contact_info`, `website_url`, `created_at`, `updated_at`, `offline_map`, `status`) VALUES
(5, 'Mysore Palace', 'Mysore', 'A historical palace and royal residence in Mysore.', 'MysorePalace.jpg', '1912', 'Monument', '12.30520000', '76.65510000', '70.00', '10:00 AM - 5:30 PM', '+91-777-8889900', 'https://mysorepalace.gov.in', '2025-01-10 05:14:01', '2025-01-11 12:56:28', 'None', 'Available'),
(9, 'Victoria Memorial', 'Kolkata', 'A large marble building dedicated to the memory of Queen Victoria.', 'VictoriaMemorial.jpg', '1921', 'Monument', '22.54480000', '88.34260000', '30.00', '10:00 AM - 6:00 PM', '+91-777-6665544', 'https://victoriamemorial.gov.in', '2025-01-10 05:14:01', '2025-01-11 13:06:46', 'None', 'Available'),
(35, 'Vijaydurg ', 'district Sindhudurg, Maharashtra', 'Vijaydurg Fort, located in Maharashtra, India, is a historically significant coastal fort with a rich past and a strategic location on the Arabian Sea. Initially known as \"Gheria,\" it was renamed \"Vijaydurg\" (meaning \"Fort of Victory\") after being captured by Chhatrapati Shivaji Maharaj in 1653. ', 'vijaydurg.jpg', '1205', 'Forts', '16.5519', '73.3354', '5', '10', '9870106259', 'https://maharashtratourism.gov.in/fort/vijaydurg/', '2025-04-30 14:26:35', '2025-04-30 14:26:35', 'vijaydurg.jpg', 'Available'),
(36, 'Golconda ', ' Hyderabad', 'Golconda Fort is located in the city of Hyderabad, India. It was originally a mud fort named Mankal and was built in the year 1143. Spanning over several centuries, this majestic fort has witnessed the rise and fall of kingdoms, becoming a symbol of power, grandeur and cultural heritage.', 'GOLKONDA.jpg', '1501', 'Forts', '17.3833', '78.4025', '200', '8.30', '1800 4254 6464', 'https://www.tripadvisor.in/Attraction_Review-g297586-d320673-Reviews-Golconda_Fort-Hyderabad_Hyderabad_District_Telangana.html', '2025-04-30 18:06:40', '2025-04-30 18:06:40', 'GOLKONDA.jpg', 'Available'),
(37, 'Lohagad ', 'Lonavala Maharastra', 'Lohagad is one of the many hill forts of Maharashtra state in India. Situated close to the hill station Lonavala and 52 km (32 mi) northwest of Pune, Lohagad rises to an elevation of 1,033 m (3,389 ft) above sea level. The fort is connected to the neighboring Visapur fort by a small range. The fort was under the Lohtamia empire for the majority of the time.', 'lohgad.jpg', '1670', 'Forts', '18.694317', '73.487259', '20', '9', '8003395964', 'https://www.bing.com/search?q=lohagad%20fort%20contact&qs=n&form=QBRE&sp=-1&ghc=1&lq=0&pq=lohagad%20fort%20contact&sc=9-20&sk=&cvid=98CC866509734ACF88A8924AD144A2B6', '2025-04-30 18:29:22', '2025-04-30 18:29:22', 'lohgad.jpg', 'Available'),
(38, 'Shivneri Fort', 'pune', 'Shivneri Fort, located near Junnar in Pune district, Maharashtra, is a 17th-century military fortification and the birthplace of Chhatrapati Shivaji Maharaj, the founder of the Maratha Empire. This triangular fort, surrounded by steep cliffs, is a significant historical site steeped in the valor of the Maratha dynasty.', 'shivneri.jpg', '1503', 'Forts', '738595.0', '191990.0', '0', '8', '090110 17688', 'https://pune.gov.in/tourist-place/shivneri/', '2025-04-30 18:58:02', '2025-04-30 18:58:02', 'shivneri.jpg', 'Available'),
(39, 'Fort Kochi', 'Kochi, Kerala, India', 'Fort Kochi, a historic neighborhood in Kochi, Kerala, is known for its rich history, diverse culture, and colonial-era architecture. It\'s a major tourist destination, offering a glimpse into India\'s past interactions with European powers, including the Portuguese, Dutch, and British. The area is characterized by its old buildings, churches, and the iconic Chinese fishing nets', 'kochi.jpg', '1503', 'Forts', '9.9658', '76.2421', '2', '24', '0484 2215006', 'https://ernakulam.nic.in/en/tourist-place/fort-kochi/', '2025-04-30 19:01:17', '2025-04-30 19:01:17', 'kochi.jpg', 'Available'),
(40, 'George Fort ', 'Chennai, Tamilnadu', 'Called the White Town, the fort was built in the 1640s to protect the trade interests of the East India Company, a brutal British trading firm with a private army that conquered, subjugated and plundered India for more than a century.', 'george.jpg', '1640', 'Forts', '13.0813', '80.2865', '250', '9:00Am - 5:00PM', '044 2567 1127', 'https://www.tamilnadutourism.tn.gov.in/destinations/fort-st-george', '2025-04-30 19:07:18', '2025-05-02 18:18:14', 'george.jpg', 'NotAvailable'),
(41, 'Janjira Fort', 'Murud, Maharastra', 'Murud-Janjira Fort is situated on an oval-shaped rock off the Arabian Sea coast near the port city of Murud, 165 km (103 mi) south of Mumbai, in the middle of the western Indian coastline. Janjira is considered one of the strongest coastal forts in India. The fort is approached by sailboats from Rajapuri jetty.', 'janjira.jpg', '1567', 'Forts', '18.2999', '72.9644', '50', '7:00 a.m. to 6:00 p.m', '02144274026', 'https://www.murudjanjiratourism.in/contact/view/EN', '2025-04-30 19:12:08', '2025-04-30 19:12:08', 'janjira.jpg', 'Available'),
(42, 'Torna Fort', 'pune, maharashtra', 'A \"torana\" is a free-standing, ornamental or arched gateway, commonly seen in Hindu, Buddhist, and Jain architecture, particularly in the Indian subcontinent and Southeast Asia', 'torna.jpg', '1201', 'Forts', '18.2769', '73.6219', '0', '8 am - 5 pm', '412212', 'https://www.fortsmaharashtra.com/torna-fort-prachandgad/', '2025-04-30 19:32:10', '2025-04-30 19:32:10', 'torna.jpg', 'Available'),
(43, 'Visapur Fort', 'lonavala, maharashtra', 'Visapur Fort is a historic hill fort located near Lonavala, Maharashtra, India. Built in the early 18th century by Balaji Vishwanath, the first Peshwa of the Maratha Empire, it served as a strategically important military outpost during the Maratha-Mughal conflicts and later during the Anglo-Maratha Wars. Today, it\'s a popular tourist attraction and offers a challenging but rewarding trek to its summi', 'Visapur.jpg', '1720', 'Forts', '17.577', '73.2706', '100', '5am 8pm', '100', 'https://www.tripadvisor.in/Attraction_Review-g297654-d1203659-Reviews-Visapur_Fort-Pune_Pune_District_Maharashtra.html', '2025-05-01 08:10:09', '2025-05-01 08:10:09', 'Visapur.jpg', 'Available'),
(44, 'Fatehpur Sikri fort', 'Agra', 'Fatehpur Sikri, meaning \"City of Victory,\" was a planned city built by Mughal Emperor Akbar, serving as his capital and court from 1572 to 1585. A UNESCO World Heritage site, it showcases a blend of Indo-Islamic architectural styles and was constructed using red sandstone. The city was abandoned due to a combination of water scarcity and political reasons, but its architectural brilliance and historical significance continue to attract visitors', 'Fatehpur.jpg', '1569', 'Forts', '27.0945', '77.6679', '40', '6am 6pm', '05613-282248', 'https://www.tajmahal.gov.in/fatehpur-sikri.aspx', '2025-05-01 08:14:24', '2025-05-01 08:14:24', 'Fatehpur.jpg', 'Available'),
(46, 'Bijapur Fort', 'Bijapur, karnataka', 'Bijapur is sometimes referred to as the Agra of the South due to the city\'s abundance of spectacular landmarks, the most famous of which is the Bijapur Fort. This fort was constructed by Yusuf Adil Shahi around 1565. The fort\'s outside wall extends for a distance of 10 kilometres', 'bijapur.png', '1566', 'Forts', '16.8297', '75.7382', '50', '6.15am - 6.00pm', '8044464837', 'https://www.indiamart.com/proddetail/bijapur-fort-6281163133.html?srsltid=AfmBOorZwo-iwEEAImNQR3az30sQ62wu6VzgcfDxpgqUCxxMrISHYW9T', '2025-05-01 08:23:19', '2025-05-01 08:23:19', 'bijapur.png', 'Available'),
(47, 'Kangra Fort', 'Himachal Pradesh', 'The Kangra Fort, located in Himachal Pradesh, India, is a historical landmark known for its impressive size and age. It is one of the largest forts in the Himalayas and is believed to be one of the oldest forts in India. Built by the Katoch dynasty, the fort is situated on a strategic hillock between two rivers and overlooks the Kangra Valley', 'Kangra.webp', '1500', 'Forts', '32.0875', '76.2542', '250', '9.00AM 5.00PM', '6994446573', 'https://www.tripadvisor.in/Attraction_Review-g1380886-d4401051-Reviews-Kangra_Fort-Kangra_Kangra_District_Himachal_Pradesh.html', '2025-05-01 08:30:38', '2025-05-01 08:30:38', 'Kangra.webp', 'Available'),
(51, 'Ellora Caves', 'Chhatrapati sambhaji nagar', 'The Ellora caves, locally known as \'Verul Leni\' is located on the Chhatrapati sambhaji nagar -Chalisgaon road at a distance of 30 km north-northwest of Chhatrapati sambhaji nagar, the district headquarters. The name Ellora itself inspires everyone as it represents one of the largest rock-hewn monastic-temple complexes in the entire world', 'ellora.jpg', '1615', 'Monument', '20.0268', '75.1771', '50', '6&#8239;am6&#8239;pm', '431102', 'https://asi.nic.in/pages/WorldHeritageElloraCaves', '2025-05-01 18:27:55', '2025-05-01 18:31:27', 'ellora.jpg', 'NotAvailable'),
(53, 'Ellora Caves ', 'Chhatrapati sambhaji nagar', 'The Ellora caves, locally known as \'Verul Leni\' is located on the Chhatrapati sambhaji nagar-Chalisgaon road at a distance of 30 km north-northwest of Chhatrapati sambhaji nagar, the district headquarters. The name Ellora itself inspires everyone as it represents one of the largest rock-hewn monastic-temple complexes in the entire world', 'ellora.jpg', '1615', 'Heritage', '20.0268', '75.1771', '40', '6&#8239;am6&#8239;pm', '431102', 'https://asi.nic.in/pages/WorldHeritageElloraCaves', '2025-05-01 18:42:40', '2025-05-01 18:42:40', 'ellora.jpg', 'Available'),
(54, 'Elephanta Caves ', 'Mumbai', 'The Elephanta Caves are special due to their remarkable rock-cut architecture, intricate sculptures, and religious significance', 'elephanta.jpg', '1987', 'Heritage', '18.9633', '72.9315', '40', '9&#8239;am5&#8239;pm', '24078388', 'https://elephanta.co.in/', '2025-05-01 18:47:43', '2025-05-01 18:47:43', 'elephanta.jpg', 'Available'),
(55, 'Bibi Ka Maqbara', 'Chhatrapati sambhaji nagar', 'The Bibi Ka Maqbara (English: \"Tomb of the Lady\") is a tomb located in the city of Chhatrapati sambhaji nagar in the Indian state of Maharashtra. It was commissioned in 1660 by the Mughal emperor Aurangzeb\'s son, Prince Azam Shah, in the memory of his mother Dilras Banu Begum (posthumously known as Rabia-ul-Durrani)', 'bibikamaqbara.avif', '1668', 'Heritage', '19.9015', '75.3203', '300', '8:00 am  8:00 pm', '02402400620', 'https://asi.payumoney.com/quick/bkm', '2025-05-01 18:50:15', '2025-05-01 18:50:15', 'bibikamaqbara.avif', 'Available'),
(56, 'Shaniwar Wada', 'Pune', 'Shaniwar Wada a 13 storey palace of Peshwas was built by Bajirao-I, in the year 1736.It was head quarter of the Peshwas and it symbolizes Pune\'s culture. The structure was built giving security the highest priority. The main entrance is known as \'Delhi Darwaja\' & others have names like Ganesh, Mastani, Jambhal, Khidki', 'shaniwar wada[1].jpg', '1732', 'Heritage', '18.5196', '73.8554', '20', '9:30  to  5.00', '25501355', 'https://pune.gov.in/tourist-place/shaniwarwada/', '2025-05-01 18:52:46', '2025-05-01 18:52:46', 'shaniwar wada[1].jpg', 'Available'),
(57, 'Karla Caves ', 'Lonavala', 'It is one of the best-known of them because of the famous \"Grand Chaitya\" (Cave 8), which is the largest and most completely preserved\" chaitya hall of the period, as well as containing unusual quantities of fine sculpture, much of it on a large scale', 'karla.jpg', '200', 'Heritage', '18.7833', '73.4704', '200', '9:00 AM - 5:00 PM', '022220267', 'https://www.lonavalavilla.com/post/karla-cave-lonavala', '2025-05-01 18:56:18', '2025-05-01 18:56:18', 'karla.jpg', 'Available'),
(58, 'Gateway of India ', 'Mumbai', 'The Gateway of India is located on the waterfront at Apollo Bunder area at the end of Chhatrapati Shivaji Marg in South Mumbai and overlooks the Arabian Sea', 'gatway.jpg', '1911', 'Heritage', '18.922', '72.8347', '00', '9am to  8 PM.', '377134', 'https://mumbaicity.gov.in/tourist-place/gateway-of-india/', '2025-05-01 18:58:46', '2025-05-01 18:58:46', 'gatway.jpg', 'Available'),
(59, 'Khajuraho Group of Monuments', 'Madhya Pradesh', 'Built in the mediaeval century by the Chandela Dynasty, the UNESCO site of \'Khajuraho Group of Monuments\' is famous for its Nagara-Style architecture and graceful sculptures of nayikas (Hindu Mythological female protagonists) and deities', 'khajuraho.jpg', '1986', 'Heritage', '24.8318', '79.9199', '50', '8 am to 6 pm', '8602415583', 'https://www.mptourism.com/destination-khajuraho.php', '2025-05-01 19:01:00', '2025-05-01 19:01:00', 'khajuraho.jpg', 'Available'),
(60, 'Jantar Mantar', 'Jaipur', 'Jantar Mantar is special because it\'s a collection of architectural astronomical instruments designed for precise timekeeping, celestial observation, and predicting astronomical events. It showcases India\'s rich scientific heritage and is recognized as a UNESCO World Heritage Site for its architectural brilliance and historical significance', 'jantar.jpg', '1724', 'Heritage', '28.6271', '77.2166', '5', '6 AM - 6 PM', '33179', 'https://www.jantarmantar.org/', '2025-05-01 19:07:11', '2025-05-01 19:07:11', 'jantar.jpg', 'Available'),
(63, 'Badami Caves', 'Karnataka', 'What makes the Badami cave temples particularly impressive is their harmonious combination of architectural styles. Their exquisite mixture of North Indian Nagara and South Indian Dravidian styles is truly amazing and makes these temples a true architectural treasure.', 'bedami.jpg', '800', 'Heritage', '15.9183', '75.6841', '20', '06:00 am  06:00 pm', '9448440220', 'https://bagalkot.nic.in/en/tourist-place/badami-caves/', '2025-05-01 19:16:28', '2025-05-01 19:16:28', 'bedami.jpg', 'Available'),
(64, 'Western Ghats', 'Maharashtra, Kerala, Tamil Nadu', 'The Western Ghats, a UNESCO World Heritage Site, is a mountain range running parallel to India\'s western coast, spanning six states: Maharashtra, Goa, Karnataka, Kerala, and Tamil Nadu. It\'s known for its diverse flora and fauna, including unique species and high biodiversity. The range also influences Indian monsoon weather patterns and is considered a significant watershed.', 'westernGhat.jpg', '2012', 'Heritage', '7236.0', '8054.0', '00', '24 hour', '00000000', 'https://whc.unesco.org/en/list/1342/', '2025-05-01 19:20:08', '2025-05-01 19:20:08', 'westernGhat.jpg', 'Available'),
(65, 'Kaziranga National Park', 'Assam ', 'Kaziranga National Park was inscribed on the World Heritage List in 1985 for its large population of one-horned rhino, tigers, elephants, panthers, bears and many birds, and its representation of the Brahmaputra floodplain and grassland ecosystem undisturbed by man.', 'kaziranga.jpg', '1985', 'Heritage', '26.6445', '93.3525', '100', '7:00 AM. - 7:00 pm.', '03776262428', 'https://golaghat.assam.gov.in/tourist-place-detail/218', '2025-05-01 19:21:54', '2025-05-01 19:21:54', 'kaziranga.jpg', 'Available'),
(66, 'Hampi', 'Karnataka', 'Hampi, a UNESCO World Heritage Site in Karnataka, India, is renowned for its stunning ruins of the medieval Vijayanagara Empire, which once ruled a vast territory in South India. Situated in the Tungabhadra basin, Hampi is known as the \"World\'s Largest Open-air Museum\" and offers a glimpse into the history and architecture of this once-mighty kingdom.', 'Hampi.jpg', '1986', 'Heritage', '15.2004', '76.2744', '30', '10:00 am  5:00 pm', '08394241661', 'https://karnatakatourism.org/tour-item/hampi/', '2025-05-01 19:24:11', '2025-05-01 19:24:11', 'Hampi.jpg', 'Available'),
(67, 'Eiffel Tower', 'Paris, France', 'The Eiffel Tower is special for several reasons: it\'s an iconic symbol of Paris and France, a remarkable feat of engineering, and a popular tourist attraction', 'Eiffel Tower.jpg', '1889', 'Monument', '48.8584', '2.2945', '0', '24 hour', '00000000', 'https://www.toureiffel.paris/en', '2025-05-02 17:35:37', '2025-05-02 17:35:37', 'Eiffel Tower.jpg', 'Available'),
(68, 'Statue of Liberty', 'New York, USA', 'The Statue of Liberty is a colossal neoclassical sculpture on Liberty Island in New York Harbor, gifted from France to the United States in 1886. It is a symbol of freedom, democracy, and the United States\' relationship with France. The statue commemorates the centennial of the Declaration of Independence and the friendship between the two nations.', 'Statue of Liberty.jpg', '886', 'Monument', '40.6892', '74.0445', '0', '24 hour', '00000000', 'https://www.nps.gov/stli/index.htm', '2025-05-02 17:37:25', '2025-05-02 17:37:25', 'Statue of Liberty.jpg', 'Available'),
(69, 'Great Wall of China', 'China', 'The Great Wall was continuously built from the 3rd century BC to the 17th century AD on the northern border of the country as the great military defence project of successive Chinese Empires, with a total length of more than 20,000 kilometers.', 'Great Wall of China.jpg', '700', 'Monument', '40.4319', '116.5704', '0', '24 hour', '00000000', 'https://www.mutianyugreatwall.com/', '2025-05-02 17:39:55', '2025-05-02 17:39:55', 'Great Wall of China.jpg', 'Available'),
(70, 'pyramids of Giza', 'Egypt', 'The pyramids are historically significant because they were constructed for religious and burial purposes. The pyramids of Giza were constructed to honor the pharaoh and to serve as his tomb after death. The pyramids are also evidence of the sophistication of ancient Egyptian societies', 'pyramids of Giza.jpg', '2580', 'Monument', '29.9792', '31.1342', '0', '24 hour', '00000000', 'https://egymonuments.gov.eg/archaeological-sites/giza-plateau/', '2025-05-02 17:41:50', '2025-05-02 17:41:50', 'pyramids of Giza.jpg', 'Available'),
(71, 'Rashtrapati Bhavan', 'Delhi', 'Rashtrapati Bhavan, home to the President of the world\'s largest democracy, is emblematic of Indian democracy and its secular, plural and inclusive traditions. It was designed by Sir Edwin Lutyens and Herbert Baker and stands on a 330 acre estate.', 'rb dehli.jpg', '1929', 'Monument', '28.6139', '77.209', '0', '24', '00000000', 'https://rashtrapatibhavan.gov.in/', '2025-05-02 17:43:30', '2025-05-02 17:43:30', 'rb dehli.jpg', 'Available'),
(72, 'Amar Jawan Jyoti', 'Delhi', 'Amar Jawan Jyoti (AJJ)\r\nAn inverted bayonet with a helmet structure along with Amar Jawan Jyoti was installed over night under the Arch of India Gate in January 1972 to commemorate India\'s victory in India - Pakistan War 1971 and as Nation\'s tribute to our brave soldiers who laid down their lives', 'amar j j.jpg', '1971', 'Monument', '28.6127', '77.2245', '0', '24 hour', '00000000', 'https://nwmm.php-staging.com/about-memorial#:~:text=Jyoti%20(AJJ)-,Amar%20Jawan%20Jyoti%20(AJJ),who%20laid%20down%20their%20lives', '2025-05-02 17:45:05', '2025-05-02 17:45:05', 'amar j j.jpg', 'Available'),
(73, 'Chhatrapati Shivaji Terminus', 'Mumbai', 'CST (Chhatrapati Shivaji Terminus, previously Victoria Terminus) was built in 1878 as an outstanding example of Victorian-Gothic architecture in India. Recognized as a World Heritage Site by UNESCO in 1997 and recognized as such by most photographers; today it ranks second as an architectural marvel within India.', 'Chhatrapati Shivaji Terminus.jpg', '1887', 'Monument', '18.94', '72.8347', '0', '24 hour', '00000000', 'https://www.incredibleindia.gov.in/en/maharashtra/mumbai/chhatrapati-shivaji-terminus', '2025-05-02 17:47:07', '2025-05-02 17:47:07', 'Chhatrapati Shivaji Terminus.jpg', 'Available'),
(75, 'Christ the Redeemer', 'Brazil', 'Christ the Redeemer is a monumental Art Deco statue of Jesus Christ in Rio de Janeiro, Brazil. It is situated on the peak of Corcovado mountain, offering panoramic views of the city. The statue, 30 meters tall, was completed in 1931 and has become a globally recognized symbol of Christianity and a cultural icon of Brazil.', 'Christ the Redeemer.jpg', '1931', 'Monument', '22.9519', '43.2105', '0', '24 hour', '00000000', 'https://www.paineirascorcovado.com.br/cristo-redentor/?lang=en', '2025-05-02 17:50:15', '2025-05-02 17:50:15', 'Christ the Redeemer.jpg', 'Available'),
(76, 'Machu Picchu', 'Peru', 'Machu Picchu is a 15th-century Inca citadel in Peru, situated high in the Andes Mountains. It is a UNESCO World Heritage site and is often referred to as the \"Lost City of the Incas\". The site was built around 1450 and abandoned a century later, likely due to the Spanish invasion and/or internal conflict.', 'Machu Picchu.jpg', '1500', 'Monument', '13.1631', '72.545', '0', '24 hour', '000000000', 'https://www.britannica.com/place/Machu-Picchu', '2025-05-02 17:51:38', '2025-05-02 17:51:38', 'Machu Picchu.jpg', 'Available'),
(77, 'Chichen Itza', 'Mexico', 'Chichen Itza is a complex of Mayan ruins centrally located on the northern half of Mexico\'s Yucatan Peninsula. In ancient, pre-Colombian times, Chichen Itza was a vibrant city with a diverse population of Mayan people extending well into the tens of thousands', 'Chichen Itza.jpg', '600', 'Monument', '20.6848', '88.5678', '0', '24 hour', '000000000', 'https://www.cancun-adventure.com/en/blog/7-facts-about-chichen-itza-in-mexico/#:~:text=Chichen%20Itza%20is%20a%20complex,into%20the%20tens%20of%20thousands', '2025-05-02 17:52:58', '2025-05-02 17:52:58', 'Chichen Itza.jpg', 'Available'),
(78, 'Roman Colosseum', 'Italy', 'The building became known as the Colosseum because of a colossal statue that stood nearby. It was built in the 1st century CE at the behest of the emperors of the Flavian dynasty', 'Roman Colosseum.jpg', '70', 'Monument', '41.8902', '12.4922', '0', '24 hour', '00000000', 'https://www.britannica.com/topic/Colosseum', '2025-05-02 17:54:05', '2025-05-02 17:54:05', 'Roman Colosseum.jpg', 'Available'),
(79, 'Big Ben (Elizabeth Tower)', 'London, UK', 'Big Ben is a British cultural icon. It is one of the most prominent symbols of the United Kingdom and parliamentary democracy, and it is often used in the establishing shot of films set in London architecture.', 'Big Ben (Elizabeth Tower).jpg', '1973', 'Monument', '51.5007', '0.1246', '0', '24 hour', '00000000', 'https://www.parliament.uk/about/living-heritage/building/palace/big-ben/', '2025-05-02 17:57:38', '2025-05-02 17:57:38', 'Big Ben (Elizabeth Tower).jpg', 'Available'),
(80, 'Neuschwanstein Castle', 'Germany', 'Neuschwanstein Castle, located in Bavaria, Germany, is a 19th-century historicist palace built by King Ludwig II of Bavaria. It\'s renowned as a fairy-tale castle and is one of the most visited attractions in Europe.', 'Neuschwanstein Castle.jpg', '1869', 'Monument', '47.5575', '10.7498', '0', '24 hour', '00000000', 'https://www.neuschwanstein.de/englisch/tourist/', '2025-05-02 17:59:03', '2025-05-02 17:59:03', 'Neuschwanstein Castle.jpg', 'Available'),
(81, 'Angkor Wat', 'Cambodia', 'Angkor Wat, temple complex at Angkor, near Siem Reap, Cambodia, that was built in the 12th century by King Suryavarman II (reigned 1113c. 1150) of the Khmer empire. The vast religious complex of Angkor Wat comprises more than a thousand buildings, and it is one of the great cultural wonders of the world.', 'Angkor Wat.jpg', '1200', 'Monument', '13.4125', '103.8667', '00', '24 hour', '00000000', 'https://www.britannica.com/topic/Angkor-Wat', '2025-05-02 18:00:02', '2025-05-02 18:00:02', 'Angkor Wat.jpg', 'Available'),
(82, 'Moai Statues', 'Easter Island, Chile', 'Easter Island: What to do, see, eat on Rapa Nui including ...The Moai statues, colossal monolithic human figures, are a defining feature of Easter Island (Rapa Nui), a special territory of Chile. They were carved by the Rapa Nui people between 1250 and 1500 CE and represent their deified ancestors. These statues are primarily made of volcanic tuff from the Rano Raraku quarry and are often found on stone platforms called ahu', 'Moai Statues.jpg', '1400', 'Monument', '27.1127', '109.3602', '0', '24 hour', '0000000000', 'https://www.easterisland.travel/easter-island-facts-and-info/moai-statues/', '2025-05-02 18:01:11', '2025-05-02 18:01:11', 'Moai Statues.jpg', 'Available'),
(83, 'Hagia Sophia', 'Istanbul, Turkey', 'A UNESCO World Heritage Site, the Hagia Sophia is a monumental structure in Istanbul that has served as a church, mosque, and museum throughout its 1,500+ year history. Currently functioning as a mosque, it remains a significant attraction for its architectural marvels and unique blend of religious influences', 'Hagia Sophia.jpg', '537', 'Monument', '41.0086', '28.9802', '0', '24 hour', '00000000', 'https://www.hagia-sophia-tickets.com/about/', '2025-05-02 18:02:14', '2025-05-02 18:02:14', 'Hagia Sophia.jpg', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `hospital_details`
--

CREATE TABLE `hospital_details` (
  `h_id` int(11) NOT NULL,
  `h_name` varchar(50) DEFAULT NULL,
  `h_lat` varchar(30) DEFAULT NULL,
  `h_long` varchar(30) DEFAULT NULL,
  `h_mobile` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hospital_details`
--

INSERT INTO `hospital_details` (`h_id`, `h_name`, `h_lat`, `h_long`, `h_mobile`) VALUES
(1, 'A Malkapur Hospital', '20.885628', '76.202502 ', '9307636926'),
(2, 'B Buldhana Hospital ', '20.530618', '76.184574', '9307636926'),
(3, 'C Akola Hospital', '20.710601', '77.014366', '9307636926'),
(4, 'Shegaon Hospital', '20.790013', '76.688980', '9307636926'),
(5, 'Akurdi Hospital', '18.652739', '73.780257', '9307636926'),
(6, 'Shivaji Nagar Hospital', '18.529770', '73.845818', '9307636926'),
(7, 'Talegaon Hospital', '73.674728', '18.738045', '9307636926'),
(8, 'Lonavala Hospital', '18.755412', '73.409147', '9307636926');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `job_id` int(11) NOT NULL,
  `job_title` varchar(255) DEFAULT NULL,
  `job_type` varchar(100) DEFAULT NULL,
  `salary_range` varchar(50) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `posted_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `application_deadline` date DEFAULT NULL,
  `experience_required` varchar(30) DEFAULT NULL,
  `skills_required` text DEFAULT NULL,
  `job_status` varchar(100) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `application_url` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`job_id`, `job_title`, `job_type`, `salary_range`, `location`, `company_name`, `posted_date`, `application_deadline`, `experience_required`, `skills_required`, `job_status`, `contact_email`, `application_url`, `status`) VALUES
(1, 'Software Engineer', 'Full-Time', '$60k-$80k', 'San Francisco, CA', 'TechCorp', '2025-01-10 04:46:52', '2025-02-15', '2', 'Java, Spring Boot, SQL', 'Open', 'hr@techcorp.com', 'https://techcorp.com/careers/apply', NULL),
(2, 'Software Developer', 'Full-Time', '50,000 - 70,000 USD', 'New York, NY', 'Tech Corp', '2024-12-31 18:30:00', '2025-02-01', '2', 'Java, Spring Boot, SQL', '', 'developer@techcorp.com', 'http://techcorp.com/careers/123', NULL),
(3, 'Product Manager', 'Full-Time', '80,000 - 100,000 USD', 'San Francisco, CA', 'Product Masters', '2025-01-09 18:30:00', '2025-03-01', '3', 'Agile, Project Management, UX', '', 'pm@productmasters.com', 'http://productmasters.com/careers/789', NULL),
(5, 'Marketing Specialist', 'Part-Time', '40,000 - 50,000 USD', 'Austin, TX', 'Marketing Pro', '2025-01-19 18:30:00', '2025-03-01', '1+ years', 'SEO, Google Analytics, Content Creation', '', 'marketing@marketingpro.com', 'http://marketingpro.com/jobs/345', NULL),
(6, 'Data Analyst', 'Part-Time', '30,000 - 40,000 USD', 'Los Angeles, CA', 'Data Solutions', '2025-01-04 18:30:00', '2025-02-05', '1+ years', 'Excel, SQL, Python', '', 'analyst@datasolutions.com', 'http://datasolutions.com/jobs/456', NULL),
(7, 'Product Manager', 'Full-Time', '80,000 - 100,000 USD', 'San Francisco, CA', 'Product Masters', '2025-01-09 18:30:00', '2025-03-01', '3+ years', 'Agile, Project Management, UX', '', 'pm@productmasters.com', 'http://productmasters.com/careers/789', NULL),
(8, 'UX/UI Designer', 'Full-Time', '60,000 - 80,000 USD', 'Chicago, IL', 'Design Innovators', '2025-01-14 18:30:00', '2025-02-15', '2+ years', 'Sketch, Figma, Adobe XD', '', 'designer@designinnovators.com', 'http://designinnovators.com/careers/012', NULL),
(9, 'Software Developer', 'Full-Time', '50,000 - 70,000 USD', 'New York, NY', 'Tech Corp', '2024-12-31 18:30:00', '2025-02-01', '2+ years', 'Java, Spring Boot, SQL', '', 'developer@techcorp.com', 'http://techcorp.com/careers/123', NULL),
(10, 'A', 'Full-Time', 'sal Range', 'Pune', NULL, '2025-01-10 18:30:00', '2025-01-11', 'Exp Req', 'skill', 'Closed', 'rr@gmail.com', 'https://techcorp.com/careers/apply', NULL),
(11, 'Job Title', 'Full-Time', '10-20', 'Pune', 'SGMS Infotech', '2000-12-11 18:30:00', '2000-12-12', '2', 'java', 'Open', 'rr@gmail.com', 'https://sgms.com/careers/apply', NULL),
(12, 'vcv', 'Full-Time', '2445', 'at post asalgaon tq jalgaon jamod dist buldhana', 'Xclusive', '2025-03-18 18:30:00', '2025-03-23', 'xv', 'sdgds', 'Open', 'coemalkapur@rediffmail.com', 'https://chatgpt.com/c/67db1659-c268-8011-a2ef-fbf5d9ef6ce6', NULL),
(13, 'BARC Recruitment ', 'Full-Time', '35000', 'mumbai', 'BARC', '2025-03-31 18:30:00', '2025-04-30', 'No', '60% &#2327;&#2369;&#2339;&#2366;&#2306;&#2360;&#2361; B.Sc. &#2310;&#2339;&#2367; 55% &#2327;&#2369;&#2339;&#2366;&#2306;&#2360;&#2361; M.Sc. (&#2347;&#2367;&#2332;&#2367;&#2325;&#2381;&#2360;/&#2325;&#2375;&#2350;&#2367;&#2360;&#2381;&#2335;&#2381;&#2352;&#2368;/&#2354;&#2366;&#2312;&#2347; &#2360;&#2366;&#2351;&#2344;&#2381;&#2360;)', 'Open', 'xyz@gmail.com', 'https://www.barc.gov.in/', NULL),
(14, 'BARC Recruitment ', 'Full-Time', '35000', 'mumbai', 'BARC', '2025-04-17 18:30:00', '2025-04-08', 'No', '60% &#2327;&#2369;&#2339;&#2366;&#2306;&#2360;&#2361; B.Sc. &#2310;&#2339;&#2367; 55% &#2327;&#2369;&#2339;&#2366;&#2306;&#2360;&#2361; M.Sc. (&#2347;&#2367;&#2332;&#2367;&#2325;&#2381;&#2360;/&#2325;&#2375;&#2350;&#2367;&#2360;&#2381;&#2335;&#2381;&#2352;&#2368;/&#2354;&#2366;&#2312;&#2347; &#2360;&#2366;&#2351;&#2344;&#2381;&#2360;)', 'Open', 'xyz@gmail.com', 'https://www.barc.gov.in/', NULL),
(15, 'Software Developer', 'Full-Time', '3.5-4.25 Lacs P.A', 'Pune', 'Cybernetics software', '2025-04-28 18:30:00', '2025-05-15', '0-1 year', 'Pursuing/completed a degree in Computer Science/IT or related field.  Proficiency in Java, .NET, C#, JavaScript.  Strong problem-solving and teamwork skills', 'Open', 'jayshree.csplsoftware@gmail.com', 'https://www.naukri.com/job-listings-software-developer-cybernetics-software-pvt-ltd-pune-0-to-1-years-280425008342?src=drecomm_apply&sid=17462583685018502&xp=8&px=1', NULL),
(16, 'Customer Retention - Voice / Blended', 'Full-Time', '3.25-4.25 Lacs P.A', 'Pune', 'AM Infoweb', '2025-04-07 18:30:00', '2025-07-17', '0-1 year', 'communication skill , management skill', 'Open', 'sharvary.navhate@aminfoweb.co.in', 'https://www.naukri.com/job-listings-freshers-immediate-hiring-and-joining-pune-for-international-voice-am-infoweb-pune-0-to-0-years-310524010473?src=drecomm_apply&sid=17462601914484943&xp=21&px=1 ', NULL),
(17, 'Customer Retention - Voice / Blended', 'Full-Time', '3.25-4.25 Lacs P.A', 'Pune', 'AM Infoweb', '2025-04-07 18:30:00', '2025-07-17', '0-1 year', 'communication skill , management skill', 'Open', 'sharvary.navhate@aminfoweb.co.in', 'https://www.naukri.com/job-listings-freshers-immediate-hiring-and-joining-pune-for-international-voice-am-infoweb-pune-0-to-0-years-310524010473?src=drecomm_apply&sid=17462601914484943&xp=21&px=1 ', NULL),
(19, 'Android Developer', 'Full-Time', 'Not Disclosed', 'Pune, Mukund Nagar', 'Integrity Technologies And Services', '2025-04-18 18:30:00', '2025-05-30', '0 - 1 years', '1. Knowledge of Core Java, Android SDK and Android Studio 2. Must have published at least one app on Google Playstore 3. Knowledge of web services, REST and JSON working 4. Experience up to 1 year in Android development with native.', 'Open', 'info@integrityts.com', 'https://www.naukri.com/job-listings-android-developer-integrity-technologies-and-services-pune-mukund-nagar-0-to-1-years-090425923022?src=jddesktop&sid=17462609536043395&xp=1&px=1', NULL),
(20, 'Python Developer', 'Full-Time', '3-8 Lacs P.A.', 'Pune', 'Acciojob', '2025-04-30 18:30:00', '2025-05-30', '0 - 5 years', 'Python, Fast API, Flask/Django, HTML, CSS, JavaScript, and frameworks like React.js or Node.js', 'Open', 'contactus@acciojob.com', 'https://www.naukri.com/job-listings-python-developer-acciojob-pune-0-to-5-years-170425023124?src=simjobsjd_bottom', NULL),
(21, 'Data Entry Operator', 'Full-Time', '1-2 Lacs P.A.', 'Mumbai Suburban, Mumbai (All Areas)( Powai, Sakinaka, Saki Vihar, Chandivali )', 'CBT Infotech', '2025-04-29 18:30:00', '2025-05-23', '0-1 year', 'Proficient in Advanced Excel (Vlookup, Pivot Table) and basic computer knowledge Perform data entry and utilize MS Office tools Benefits as per industry standard', 'Open', 'karisma.debbarma@cbtinfotech.com', 'https://www.naukri.com/job-listings-data-entry-operator-powai-cbt-infotech-mumbai-suburban-mumbai-all-areas-0-to-0-years-300425003336?src=jobsearchDesk&sid=17462621323726884_2&xp=6&px=1&nignbevent_src=jobsearchDeskGNB', NULL),
(22, 'Fullstack Developer', 'Full-Time', 'Not Disclosed', 'Pune', 'Avkalan.ai', '2025-04-22 18:30:00', '2025-05-24', '3 - 6 years', 'Express.js / Node.js - Advanced - Yes Java (Spring Boot) - Intermediate - Preferred NoSQL DB (MongoDB) - Advanced - Yes SQL DB (PostgreSQL) - Advanced - Yes React.js/Next Js - Advanced - Yes', 'Open', 'careers@avkalan.ai', 'https://www.naukri.com/job-listings-fullstack-developer-avkalan-ai-pune-3-to-6-years-240425012663?src=simjobsjd_bottom', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_applications`
--

CREATE TABLE `job_applications` (
  `application_id` int(11) NOT NULL,
  `student_id` varchar(255) NOT NULL,
  `job_id` varchar(255) NOT NULL,
  `application_status` varchar(255) NOT NULL,
  `applied_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `job_applications`
--

INSERT INTO `job_applications` (`application_id`, `student_id`, `job_id`, `application_status`, `applied_on`, `last_updated`) VALUES
(6, '13', '12', 'Waiting', '2025-03-22 19:42:46', '2025-03-22 19:42:46'),
(7, '13', '13', 'Waiting', '2025-04-04 13:42:19', '2025-04-04 13:42:19'),
(8, '13', '14', 'Waiting', '2025-04-04 14:20:46', '2025-04-04 14:20:46'),
(9, '13', '14', 'Waiting', '2025-04-04 14:20:51', '2025-04-04 14:20:51'),
(10, '13', '13', 'Waiting', '2025-04-24 09:35:37', '2025-04-24 09:35:37'),
(11, '13', '13', 'Waiting', '2025-04-26 17:49:48', '2025-04-26 17:49:48');

-- --------------------------------------------------------

--
-- Table structure for table `student_profiles`
--

CREATE TABLE `student_profiles` (
  `id` int(11) NOT NULL,
  `student_id` varchar(30) DEFAULT NULL,
  `full_name` varchar(255) NOT NULL,
  `dob` date NOT NULL,
  `gender` varchar(50) NOT NULL,
  `nationality` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `highest_qualification` varchar(255) NOT NULL,
  `program` varchar(255) NOT NULL,
  `institution` varchar(255) NOT NULL,
  `enrollment` varchar(50) NOT NULL,
  `graduation_year` varchar(4) NOT NULL,
  `cgpa` varchar(10) NOT NULL,
  `skills` text NOT NULL,
  `interests` text DEFAULT NULL,
  `linkedin` varchar(255) DEFAULT NULL,
  `resume` varchar(255) DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_profiles`
--

INSERT INTO `student_profiles` (`id`, `student_id`, `full_name`, `dob`, `gender`, `nationality`, `email`, `mobile`, `address`, `highest_qualification`, `program`, `institution`, `enrollment`, `graduation_year`, `cgpa`, `skills`, `interests`, `linkedin`, `resume`, `photo_path`, `created_at`, `updated_at`) VALUES
(1, '4', 'Ritesh Rama Surange', '2021-11-28', 'Male', 'Indian', 'ritesh@gmail.com', '08900890089', 'Akurdi Pune', 'MTech', 'pHD', 'DY Akurdi', '12332123', '2020', '89.00', 'Java Python AI', 'Reading', 'https://www.google.co.in/', 'https://www.google.co.in/resume', 'santaji.jpg', '2025-01-11 17:47:44', '2025-01-11 18:11:35'),
(2, '4', 'Ritesh Rama Rathod', '2000-02-11', 'Female', 'Indian', 'ritesh@gmail.com', '8000800089', 'Akurdi Pune 123123', 'MTech', 'pHD', 'DY Akurdi', '12332123', '2020', '89.00', 'Java Python AI', 'Reading', 'https://www.google.co.in/', 'https://www.google.co.in/resume', 'shiv.png', '2025-01-11 18:24:35', '2025-01-11 18:25:16'),
(3, '13', 'Tushar Anil Thombare ', '2025-03-06', 'Male', 'Indian', 'tusharthombare71@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', 'coding', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', '', '', '2025-03-19 20:11:55', '2025-03-19 20:11:55'),
(4, '13', 'Tushar Anil Thombare ', '2025-03-02', 'Male', 'Indian', 'tusharthombare71@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', 'coding', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', 'https://drive.google.com/file/d/1bNEKiVgkEB1vJ45Q9QVYfz8VwTzxtj42/view?usp=sharing', 'Ajanta.jpg', '2025-03-22 18:48:55', '2025-03-22 18:48:55'),
(5, '13', 'Tushar Anil Thombare ', '2025-03-09', 'Male', 'Indian', 'tusharthombare71@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', 'coding', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', '', 'Uploads/Ajanta.jpg', '2025-03-22 18:54:25', '2025-03-22 18:54:25'),
(6, '13', 'Tushar Anil Thombare ', '2025-03-02', 'Male', 'Indian', 'admin@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', 'coding', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', 'https://drive.google.com/file/d/1bNEKiVgkEB1vJ45Q9QVYfz8VwTzxtj42/view?usp=sharing', 'Uploads/Ajanta.jpg', '2025-03-22 19:07:07', '2025-03-22 19:07:07'),
(7, '13', 'Tushar Anil Thombare ', '2025-03-09', 'Male', 'Indian', 'tusharthombare71@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', 'coding', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', 'https://drive.google.com/file/d/1bNEKiVgkEB1vJ45Q9QVYfz8VwTzxtj42/view?usp=sharing', 'Uploads/IMG20240707084400.jpg', '2025-03-22 19:08:39', '2025-03-22 19:08:39'),
(8, '13', 'Tushar Anil Thombare ', '2025-03-01', 'Male', 'Indian', 'admin@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana\r\nat post asalgaon tq jalgaon jamod dist buldhana', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', '', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', 'https://drive.google.com/file/d/1bNEKiVgkEB1vJ45Q9QVYfz8VwTzxtj42/view?usp=sharing', 'IMG20240707084400.jpg', '2025-03-22 19:14:00', '2025-03-22 19:14:00'),
(9, '13', 'Tushar Anil Thombare ', '2001-05-22', 'Male', 'Indian', 'tusharthombare71@gmail.com', '7517744852', 'at post asalgaon tq jalgaon jamod dist buldhana\r\n', 'under graduate', 'computer Science', 'PADMASHRI DR. V. B. KOLTE COLLEGE OF ENGINEERING, MALKAPUR', '12345', '2025', '8.50', 'java, hibernate, jdbc, react ', 'coding', 'https://www.linkedin.com/in/tushar-thombare-0824b7265/', 'https://drive.google.com/file/d/1bNEKiVgkEB1vJ45Q9QVYfz8VwTzxtj42/view?usp=sharing', 'tushar.jpg', '2025-03-22 19:18:28', '2025-03-22 19:18:28'),
(10, '13', 'Himanshu Nandkishor Lahane', '2003-07-02', 'Male', 'Indian', 'himanshulahaneh3@gmail.com', '9307636926', 'New khetan nagar khaulkhed akola', 'BE Computer Science', 'Computer Science', 'Sant Gadge Baba Amravati Unviersity ', '44444', '2025', '7.5', 'Java Hibernate OOPS', 'Reading Coding', 'https://www.linkedin.com/in/himanshu-lahane-791362270/', 'https://www.linkedin.com/in/himanshu-lahane-791362270/', 'IMG-20250205-WA0038.jpg', '2025-05-04 06:47:17', '2025-05-04 06:47:17'),
(11, '13', 'Himanshu Nandkishor Lahane', '2003-07-02', 'Male', 'Indian', 'himanshulahaneh3@gmail.com', '9307636926', 'New khetan nagar khaulkhed akola', 'BE Computer Science', 'Computer Science', 'Sant Gadge Baba Amravati Unviersity ', '44444', '2025', '7.5', 'Java Hibernate OOPS', 'Reading Coding', 'https://www.linkedin.com/in/himanshu-lahane-791362270/', 'https://www.linkedin.com/in/himanshu-lahane-791362270/', 'Himanshu.jpg', '2025-05-04 06:50:37', '2025-05-04 06:50:37');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `gender` varchar(30) DEFAULT NULL,
  `dob` varchar(30) DEFAULT NULL,
  `user_type` varchar(30) DEFAULT NULL,
  `mobile` varchar(30) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(30) DEFAULT NULL,
  `acc_create` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `fname`, `lname`, `gender`, `dob`, `user_type`, `mobile`, `email`, `password`, `acc_create`) VALUES
(4, 'Ritesh', 'Surange', 'Male', '2010-02-01', 'Student', '8900890089', 'ritesh@gmail.com', '123123', '2025-01-11'),
(5, 'Ramesh', 'Rathod', 'Male', '1992-12-12', 'Traveler', '8275329929', 'ramesh@gmail.com', '123123', '2025-01-11'),
(6, 'Himanshu', 'Lahane', 'Male', '2024-12-31', 'Student', '9800980098', 'himanshu@gmail.com', '123123', '2025-01-12'),
(7, 'Rakesh', 'Jadhav', 'Male', '2000-12-12', 'Patient', '8275329929', 'rakesh@gmail.com', '123123', '2025-02-01'),
(8, 'satish', 'suradkar', 'Male', '2025-02-14', 'Patient', '7517744852', 'satish@gmail.com', 'satish123', '2025-02-13'),
(9, 'tushar ', 'thombare', 'Male', '2025-02-14', 'Traveler', '7517744852', 'tusharthombare71@gmail.com', 'thombare123', '2025-02-14'),
(10, 'satish', 'thombare', 'Male', '2025-02-21', 'Student', '7517744852', 'tusharthombare71@gmail.com', 'thombare132', '2025-02-15'),
(11, 'demo ', 'Project', 'Male', '2002-11-01', 'Traveler', '7517744852', 'demo@gmail.com', 'demo123', '2025-02-15'),
(12, 'demo ', 'Project', 'Male', '2002-02-22', 'Patient', '7517744852', 'demo@gmail.com', 'demo123', '2025-02-15'),
(13, 'demo ', 'Project', 'Male', '2002-02-22', 'Student', '7517744852', 'demo@gmail.com', 'demo123', '2025-02-15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `college_info`
--
ALTER TABLE `college_info`
  ADD PRIMARY KEY (`college_id`);

--
-- Indexes for table `diseases_medicine`
--
ALTER TABLE `diseases_medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `favorite_places`
--
ALTER TABLE `favorite_places`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `historical_places_details`
--
ALTER TABLE `historical_places_details`
  ADD PRIMARY KEY (`place_id`);

--
-- Indexes for table `hospital_details`
--
ALTER TABLE `hospital_details`
  ADD PRIMARY KEY (`h_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`job_id`);

--
-- Indexes for table `job_applications`
--
ALTER TABLE `job_applications`
  ADD PRIMARY KEY (`application_id`);

--
-- Indexes for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `college_info`
--
ALTER TABLE `college_info`
  MODIFY `college_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `diseases_medicine`
--
ALTER TABLE `diseases_medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `favorite_places`
--
ALTER TABLE `favorite_places`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `historical_places_details`
--
ALTER TABLE `historical_places_details`
  MODIFY `place_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `hospital_details`
--
ALTER TABLE `hospital_details`
  MODIFY `h_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `job_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `job_applications`
--
ALTER TABLE `job_applications`
  MODIFY `application_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `student_profiles`
--
ALTER TABLE `student_profiles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
